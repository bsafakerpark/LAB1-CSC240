package java240pac;

public class Auto {
	private String firstName;
	private String lastName;
	private String make;
	private String model;
	private double liability;
	private double collision;
	private double commission;
	
	public Auto(String firstName, String lastName, String make, String model, double liability, double collision) 
	{ this.firstName = firstName;
	  this.lastName = lastName;
	  this.make = make;
	  this.model = model;
	  this.liability = liability;
	  this.collision = collision;
	  }
	
	public void computeCommission() 
	{commission = (liability + collision) * 0.30;  }

	    public String toString() {
	    	return String.format("Auto Policy\n-----------\nName: %s %s\nMake: %s\nModel: %s\nLiability: $%,.2f\nCollision: $%,.2f\nCommission: $%,.2f\n", 
	                              firstName, lastName, make, model, liability, collision, commission);
	    }

}
