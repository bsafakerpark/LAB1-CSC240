package java240pac;

public class Home {
	private String firstName;
	private String lastName;
	private double footage;
	private double dwelling;
	private double contents;
	private double liability;
	private double commission;
	    
	public Home() {}

	public void computeCommission() 
	{  commission = (liability * 0.30) + ((dwelling + contents) * 0.20);   }

	public String toString() {
	        return String.format("Home Policy\n-----------\nName: %s %s\nFootage: %.0f\nDwelling: $%,.2f\nContents: $%,.2f\nLiability: $%,.2f\nCommission: $%,.2f\n", 
	        firstName, lastName, footage, dwelling, contents, liability, commission);
	        }

	public void setFirstName(String firstName) {
	        this.firstName = firstName;
	        }

	public void setLastName(String lastName) {
	        this.lastName = lastName;
	        }

	public void setFootage(double footage) {
	        this.footage = footage;
	        }

	public void setDwelling(double dwelling) {
	        this.dwelling = dwelling;
	        }

	public void setContents(double contents) {
	        this.contents = contents;
	        }

	public void setLiability(double liability) {
	        this.liability = liability;
	        }
	}


